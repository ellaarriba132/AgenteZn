import bs,bsInternal
import re

old = []
owner = 'Lovely'
king = 'Lovely'

def reply(ans):
    bsInternal._chatMessage(str(ans))

def answer(question):
    if 'king' in question:
        reply(king)
    elif 'owner' in question:
        reply(owner)
    elif '+' in question:
        numbers = re.findall(r'\d+',question)
        reply(int(numbers[0]) + int(numbers[1]))
    elif 'x' in question:
        numbers = re.findall(r'\d+',question)
        reply(int(numbers[0]) * int(numbers[1]))
        
def detectNewMessage():
    global old
    msgs = bsInternal._getChatMessages()
    msgs.reverse()
    if msgs != old:
        old = msgs
        for msg in msgs:
            if msg.startswith(u'server'):
                if msg.endswith('?'):
                    question = msg.split(': ')[1]
                    answer(question)
                    break
def stop():
    global timer
    timer = None
 
def start(time=2000):
    global timer
    with bs.Context('UI'):
        timer= bs.Timer(time, detectNewMessage, timeType='real', repeat=True)
        
start()

