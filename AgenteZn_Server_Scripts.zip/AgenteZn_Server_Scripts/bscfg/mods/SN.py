# coding=utf-8
from bsSpaz import *

# SANESSSS!!!
t = Appearance("SnowGuy")
t.colorTexture = "achievementFlawlessVictory"
t.colorMaskTexture = "achievementFlawlessVictory"
t . defaultColor = (1.0, 0.1, 1.2)

t . defaultHighlight = (0.16, 0.15, 2.4)
t.iconTexture = "achievementFlawlessVictory"
t.iconMaskTexture = "aliIconMask"

t.headModel = "aliHead"
t.torsoModel = "pixiePelvis"
t.pelvisModel = "pixiePelvis"
t.upperArmModel = "pixiePelvis"
t.foreArmModel = "pixiePelvis"
t.handModel = "pixiePelvis"
t.upperLegModel = "pixiePelvis"
t.lowerLegModel = "pixiePelvis"
t.toesModel = "pixiePelvis"

aliSounds =    ['ali1','ali2','ali3','ali4']
aliHitSounds = ['aliHit1','aliHit2']
t.attackSounds = aliSounds
t.jumpSounds = aliSounds
t.impactSounds = aliHitSounds
t.deathSounds=["aliDeath"]
t.pickupSounds = aliSounds
t.fallSounds=["aliFall"]
t . style = 'ali'