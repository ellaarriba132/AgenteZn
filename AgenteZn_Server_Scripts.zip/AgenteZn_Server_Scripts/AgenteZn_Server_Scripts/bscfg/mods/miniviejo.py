from bsSpaz import Appearance


t = Appearance("miniviejo")
#texture 1
t.colorTexture = "wizardColor"
t.colorMaskTexture = "wizardColorMask"
#nose jaja 
t.defaultColor = (0.2,0.8,0.8)
#t.defaultHighlight = (0.2,0.8,0.8)
#texture 2
t.iconTexture = "storeCharacter"
t.iconMaskTexture = "cuteSpazIconMask"
#Cuerpo
t.headModel =     "bunnyPelvis"
t.torsoModel =    "wizardHead"
t.pelvisModel =   "ninjaPelvis"
t.upperArmModel = "bunnyPelvis"
t.foreArmModel =  "aliForeArm"
t.handModel =     "aliHand"
t.upperLegModel = "wizardUpperLeg"
t.lowerLegModel = "wizardUpperLeg"
t.toesModel =     "neoSpazToes"
#Sonidos
t.attackSounds = ['wizard3']
t.jumpSounds = ['penguin1']
t.impactSounds = ["penguinHit2"]
t.deathSounds=['achievement']
t.pickupSounds = ['ooh']
t.fallSounds=["pixieFall"]

t.style = 'bones'  
#crado por jhoel