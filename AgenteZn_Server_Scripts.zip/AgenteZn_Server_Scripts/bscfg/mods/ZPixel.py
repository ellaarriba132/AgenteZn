# coding=utf-8
from bsSpaz import *

# SANESSSS!!!
t = Appearance("ZPixel")
t.colorTexture = "pixieColor"
t.colorMaskTexture = "pixieColorMask"
t . defaultColor = (1.0, 0.1, 1.2)

t . defaultHighlight = (0.16, 0.15, 2.4)
t.iconTexture = "zoeIcon"
t.iconMaskTexture = "pixieIconColorMask"

t.headModel = "pixieHead"
t.torsoModel = "pixieTorso"
t.pelvisModel = "pixiePelvis"
t.upperArmModel = "pixiePelvis"
t.foreArmModel = "pixiePelvis"
t.handModel = "pixieHand"
t.upperLegModel = "pixieUpperLeg"
t.lowerLegModel = "pixieLowerLeg"
t.toesModel = "pixiePelvis"

pixieSounds = ['pixie1', 'pixie2', 'pixie3', 'pixie4']
pixieHitSounds = ['pixieHit1', 'pixieHit2']
t . attackSounds = pixieSounds
t . jumpSounds = pixieSounds
t . impactSounds = pixieHitSounds
t . deathSounds = ["pixieDeath"]
t . pickupSounds = pixieSounds
t . fallSounds = ["pixieFall"]
t . style = 'female'