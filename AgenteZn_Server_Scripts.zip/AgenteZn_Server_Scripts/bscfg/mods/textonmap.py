# Released under the MIT License. See LICENSE for details.

""" TODO need to set coordinates of text node , move timer values to settings.json """

import bs, bsInternal
from datetime import datetime
import datetime
import pytz

class textonmap:

	def __init__(self):
		top = "Siguiente Mapa : "+bsInternal._getForegroundHostSession().getNextGameDescription().evaluate()
		self.top_message(top)
		self._date_and_time()

	def _date_and_time(self):
		self.date_and_time_node = bs.newNode('text',
			attrs = {
			'text': "Fuck",
			'flatness': 0.8,
			'hAlign': 'center',
			'vAttach': 'top',
			'hAttach': 'center',
			'scale': 0.6,
			'position': (0, -87),
			'color': (0.9, 0.9, 0.9)})
		def update():
			#activity=bsInternal._getForegroundHostActivity()
			#with bs.Context(activity):
			zone = pytz.timezone('America/Bogota')
			self.date_and_time_node.text = "Hora: " + str(datetime.datetime.now(zone).strftime('%I: %M: %S %p')) + ' \nFecha: ' + str(datetime.datetime.now(zone).strftime('%d / %m / %Y'))
		self.timer = bs.Timer(1, update, repeat=True)
		update()

	def top_message(self, text):
		node = bs.newNode('text',
			attrs = {
			'text': text,
			'flatness': 1.0,
			'hAlign': 'center',
			'vAttach': 'top',
			'scale': 0.6,
			'position': (0, -59),
			'color': (1, 0, 1)})
	
