# -*- coding: utf-8 -*-
import socket
import os
config['partyName'] = u'test'
config['sessionType'] = 'ffa' #In the game session you must put [ffa, teams] the coop will not work because you must have a version of 1.6 and 1.7 etc.
config['maxPartySize'] = 14 # You can change to the maximum players of your server
config['playlistCode'] = None #Here you must put a playlist of that so that you can put another game
config['telnetPassword'] = ''
config['statsURL'] = '' #Here you put your url or url of telegram or discord
config['partyIsPublic'] = True #This when you put True the server is public or when you put False the server is private
config['port'] = 43210 #If you want to change the server port. You must put 5 digits of the port

config['admin_id'] = 'pb-IF4xVUg4FA==' #This does not work but you must enter the some.py and you must put your pb in the part that says ownerid
config['vips_id'] = ''
config['coleads_id'] = ''
config['leads_id'] = ''
config['host'] = 'Agentezn' #here you put your name
config['is_logic'] = True

config['show_rank'] = True
config['show_hp'] = False
config['show_texts'] = False
config['modded_powerups'] = False
config['show_powerup_name'] = False
config['floating_landmine'] = False
config['snowfall'] = False
config['extra_sparkles'] = False
config['earned_msg'] = True
config['show_tag'] = True
config['interactive_powerups'] = False
config['powerup_shields'] = False
config['logic_team_settings'] = False
config['custom_tnt'] = False
config['translator'] = False
config['default_game_time_limit'] = 2

#Extra Features

config['PopupMessages'] = False
config['BuildEffectMap'] = True

#glowing bombs
config['bomb_light'] = False
config['transition_light_color'] = False

#efectos de ambiente
config['rgb_maps'] = False
config['fire_flies'] = False # SMOOTH GOD
config['date_and_clock'] = False
