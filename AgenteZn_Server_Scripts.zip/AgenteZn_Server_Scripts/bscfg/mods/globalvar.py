import random
uni = {'\\c': '\\ue043','\\sh': '\\ue049','\\v':'\\ue04c', '\\h': '\\ue047', '\\z':'\\ue044', '\\n': '\\ue04b', '\\b': '\\ue04b', '\\d': '\\ue048', '\\s': '\\ue046', '\\f': '\\ue04f', '\\l': '\\ue00c', '\\g': '\\ue02c', '\\t': '\\ue02f', '\\i': '\\ue03a'}
multicolor = {0:((0+random.random()*3.0),(0+random.random()*3.0),(0+random.random()*3.0)),
              250:((0+random.random()*3.0),(0+random.random()*3.0),(0+random.random()*3.0)),
              500:((0+random.random()*3.0),(0+random.random()*3.0),(0+random.random()*3.0)),
              750:((0+random.random()*3.0),(0+random.random()*3.0),(0+random.random()*3.0)),
              1000:((0+random.random()*3.0),(0+random.random()*3.0),(0+random.random()*3.0)),
              1250:((0+random.random()*3.0),(0+random.random()*3.0),(0+random.random()*3.0)),
              1500:((0+random.random()*3.0),(0+random.random()*3.0),(0+random.random()*3.0)),
              1750:((0+random.random()*3.0),(0+random.random()*3.0),(0+random.random()*3.0)),
              2000:((0+random.random()*3.0),(0+random.random()*3.0),(0+random.random()*3.0)),
              2250:((0+random.random()*3.0),(0+random.random()*3.0),(0+random.random()*3.0)),
              2500:((0+random.random()*3.0),(0+random.random()*3.0),(0+random.random()*3.0))}