# coding=utf-8
from bsSpaz import *

### Personaje De Unanaseeee Xddddddd
# Creado Por Agente Zπ
# Contiene MJ

t = Appearance("MJS")

t.colorTexture = "black"
t.colorMaskTexture = "agentIconColorMask"

t.iconTexture = "frostyIconColorMask"
t.iconMaskTexture = "frostyIconColorMask"

t.headModel = "frostyHead"
t.torsoModel = "agentTorso"
t.pelvisModel = "agentPelvis"
t.upperArmModel = "agentUpperArm"
t.foreArmModel = "bearForeArm"
t.handModel = "bearHand"
t.upperLegModel = "agentUpperLeg"
t.lowerLegModel = "agentLowerLeg"
t.toesModel = "agentToes"

penguinSounds = ['pixie1', 'pixie2', 'pixie3', 'pixie4']
penguinHitSounds = ['penguinHit2']

t.attackSounds = aliSounds
t.jumpSounds = bunnySounds
t.impactSounds = penguinHitSounds
t.deathSounds = ["error"]
t.pickupSounds = pixieSounds
t.fallSounds = ["wizardFall"]

t.style = 'agent'

#Esta muy Gracioso :D

t = Appearance("Balon")

t.colorTexture = "bombColor"
t.colorMaskTexture = "bombColorMask"

t.iconTexture = "tv"
t.iconMaskTexture = "tv"

t.headModel = "bomb"
t.torsoModel = "bomb"
t.pelvisModel = "pixieHand"
t.upperArmModel = "pixieHand"
t.foreArmModel = "pixieHand"
t.handModel = "pixieHand"
t.upperLegModel = "agentUpperLeg"
t.lowerLegModel = "agentLowerLeg"
t.toesModel = "agentToes"

penguinSounds = ['announceTen', 'announceNine', 'announceEight', 'announceSeven', 'announceSix', 'announceFive', 'announceFour', 'announceThree', 'announceTwo', 'announceOne']
spazOwSounds = ['punchStrong02']

t.attackSounds = penguinSounds
t.jumpSounds = penguinSounds
t.impactSounds = spazOwSounds
t.deathSounds = ["boo"]
t.pickupSounds = penguinSounds
t.fallSounds = ["achievement"]

t.style = 'ali'

#Personaje Bomb Hielo

t = Appearance("Bomba De Hielo")

t.colorTexture = "bombColorIce"
t.colorMaskTexture = "bombColorIce"

t.iconTexture = "powerupIceBombs"
t.iconMaskTexture = "powerupIceBombs"

t.headModel = "bomb"
t.torsoModel = "bomb"
t.pelvisModel = "pixieHand"
t.upperArmModel = "pixieHand"
t.foreArmModel = "pixieHand"
t.handModel = "pixieHand"
t.upperLegModel = "agentUpperLeg"
t.lowerLegModel = "agentLowerLeg"
t.toesModel = "agentToes"

penguinSounds = ['announceTen', 'announceNine', 'announceEight', 'announceSeven', 'announceSix', 'announceFive', 'announceFour', 'announceThree', 'announceTwo', 'announceOne']
spazOwSounds = ['punchStrong02']

t.attackSounds = penguinSounds
t.jumpSounds = penguinSounds
t.impactSounds = spazOwSounds
t.deathSounds = ["shatter"]
t.pickupSounds = penguinSounds
t.fallSounds = ["achievement"]

t.style = 'ali'

# Impact   Titititittitititititititi
t = Appearance("Impacto")

t.colorTexture = "impactBombColorLit"
t.colorMaskTexture = "impactBombColorLit"

t.defaultColor = (1,0,0)
t.defaultHighlight = (1,1,1)

t.iconTexture = "powerupImpactBombs"
t.iconMaskTexture = "powerupImpactBombs"

t.headModel = "impactBomb"
t.torsoModel = "cyborgTorso"
t.pelvisModel = "wizardPelvis"
t.upperArmModel = "ninjaUpperArm"
t.foreArmModel = "frostyForeArm"
t.handModel = "cyborgHand"
t.upperLegModel = "frostyUpperLeg"
t.lowerLegModel = "penguinLowerLeg"
t.toesModel = "cyborgToes"

penguinSounds = ['announceTen', 'announceNine', 'announceEight', 'announceSeven', 'announceSix', 'announceFive', 'announceFour', 'announceThree', 'announceTwo', 'announceOne']
spazOwSounds = ['activateBeep']

t.attackSounds = penguinSounds
t.jumpSounds = penguinSounds
t.impactSounds = spazOwSounds
t.deathSounds = ["score"]
t.pickupSounds = penguinSounds
t.fallSounds = ["warnBeep"]

t.style = 'cyborg'

# El Golpeo De Sonido: Tompson Cat
t = Appearance("TNT")

t.colorTexture = "tnt"
t.colorMaskTexture = "tnt"

t.defaultColor = (1,1,1)
t.defaultHighlight = (0,0,0)

t.iconTexture = "tnt"
t.iconMaskTexture = "tnt"

t.headModel = "powerup"
t.torsoModel = "cyborgTorso"
t.pelvisModel = "wizardPelvis"
t.upperArmModel = "ninjaUpperArm"
t.foreArmModel = "frostyForeArm"
t.handModel = "cyborgHand"
t.upperLegModel = "frostyUpperLeg"
t.lowerLegModel = "penguinLowerLeg"
t.toesModel = "cyborgToes"

penguinSounds = ['announceTen', 'announceNine', 'announceEight', 'announceSeven', 'announceSix', 'announceFive', 'announceFour', 'announceThree', 'announceTwo', 'announceOne']
spazOwSounds = ['spazOw', 'zoeOw']

t.attackSounds = penguinSounds
t.jumpSounds = penguinSounds
t.impactSounds = spazOwSounds
t.deathSounds = ["boo"]
t.pickupSounds = penguinSounds
t.fallSounds = ["achievement"]

t.style = 'cyborg'

# Huevo De Pascal
t = Appearance("Huevo")

t.colorTexture = "eggTex2"
t.colorMaskTexture = "eggTex2"

t.defaultColor = (1,1,1)
t.defaultHighlight = (1,1,1)

t.iconTexture = "egg2"
t.iconMaskTexture = "eggTex2"

t.headModel = "egg"
t.torsoModel = "melTorso"
t.pelvisModel = "wizardPelvis"
t.upperArmModel = "melUpperArm"
t.foreArmModel = "melForeArm"
t.handModel = "cyborgHand"
t.upperLegModel = "frostyUpperLeg"
t.lowerLegModel = "penguinLowerLeg"
t.toesModel = "cyborgToes"

penguinSounds = ['announceTen', 'announceNine', 'announceEight', 'announceSeven', 'announceSix', 'announceFive', 'announceFour', 'announceThree', 'announceTwo', 'announceOne']
spazOwSounds = ['bellLow', 'bellMed', 'bellHigh']

t.attackSounds = penguinSounds
t.jumpSounds = penguinSounds
t.impactSounds = spazOwSounds
t.deathSounds = ["wizardDeath"]
t.pickupSounds = penguinSounds
t.fallSounds = ["scoreIncrease"]

t.style = 'cyborg'

# Oso Mañoso >:(
t = Appearance("Pipipipipi")

t.colorTexture = "black"
t.colorMaskTexture = "black"

t.defaultColor = (1,1,1)
t.defaultHighlight = (1,1,1)

t.iconTexture = "cursor"
t.iconMaskTexture = "cursor"

t.headModel = "bearHead"
t.torsoModel = "ninjaTorso"
t.pelvisModel = "wizardPelvis"
t.upperArmModel = "melUpperArm"
t.foreArmModel = "melForeArm"
t.handModel = "cyborgHand"
t.upperLegModel = "frostyUpperLeg"
t.lowerLegModel = "penguinLowerLeg"
t.toesModel = "cyborgToes"

penguinSounds = ['laser', 'laserReverse']

pikachuSounds = ['corkPop']

spazOwSounds = ['orchestraHit', 'orchestraHit2', 'orchestraHit3', 'orchestraHit4']

t.attackSounds = penguinSounds
t.jumpSounds = penguinSounds
t.impactSounds = spazOwSounds
t.deathSounds = ["orchestraHitBig2"]
t.pickupSounds = pikachuSounds
t.fallSounds = ["orchestraHitBig1"]

t.style = 'bear'

# Blanco Color De Amor De Panamericana TV
t = Appearance("Vida Del Blanco Color De Amor")

t.colorTexture = "powerupHealth"
t.colorMaskTexture = "powerupHealth"

t.defaultColor = (1,1,1)
t.defaultHighlight = (0,0,0)

t.iconTexture = "powerupHealth"
t.iconMaskTexture = "powerupHealth"

t.headModel = "powerup"
t.torsoModel = "cyborgTorso"
t.pelvisModel = "wizardPelvis"
t.upperArmModel = "ninjaUpperArm"
t.foreArmModel = "frostyForeArm"
t.handModel = "cyborgHand"
t.upperLegModel = "frostyUpperLeg"
t.lowerLegModel = "penguinLowerLeg"
t.toesModel = "cyborgToes"

penguinSounds = ['blip']
spazOwSounds = ['pop01']

t.attackSounds = penguinSounds
t.jumpSounds = penguinSounds
t.impactSounds = spazOwSounds
t.deathSounds = ["cashRegister2"]
t.pickupSounds = penguinSounds
t.fallSounds = ["raceBeep2"]

t.style = 'cyborg'
