# coding=utf-8
from bsSpaz import *

# Penguin Dude # Created by Friends
t = Appearance("Frosty Man")
t.colorTexture = "cyborgColor"
t.colorMaskTexture = "egg2"
t.iconTexture = "achievementInControl"
t.iconMaskTexture = "eggTex1"

t.headModel = "melTorso"
t.torsoModel = "aliTorso"
t.pelvisModel = "bunnyPelvis"
t.upperArmModel = "bunnyPelvis"
t.foreArmModel = "santaForeArm"
t.handModel = "santaHand"
t.upperLegModel = "bunnyPelvis"
t.lowerLegModel = "bunnyPelvis"
t.toesModel = "bunnyToes"

t.jumpSounds=["frostyJump01",
              "frostyJump02",
              "frostyJump03",
              "frostyJump04"]
t.attackSounds=["frostyAttack01",
                "frostyAttack02",
                "frostyAttack03",
                "frostyAttack04"]
t.impactSounds=["pixieImpact01",
                "pixieImpact02",
                "pixieImpact03",
                "pixielmpact04"]
t.deathSounds=["frostyDeath01"]
t.pickupSounds=["shatter"]
t.fallSounds=["frostyFall01"]

t.style = 'agent'