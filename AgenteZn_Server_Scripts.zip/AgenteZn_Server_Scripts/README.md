# sempai_server_script
