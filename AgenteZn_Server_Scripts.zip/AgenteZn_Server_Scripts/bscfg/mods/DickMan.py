# coding=utf-8
from bsSpaz import *

# SANESSSS!!!
t = Appearance("DickMan")
t.colorTexture = "shield"
t.colorMaskTexture = "shield"
t.iconTexture = "santaIcon"
t.iconMaskTexture = "neoSpazIconMask"

t.headModel = "penguinTorso"
t.torsoModel = "santaTorso"
t.pelvisModel = "frostyHand"
t.upperArmModel = "frostyHand"
t.foreArmModel = "frostyHand"
t.handModel = "frostyHand"
t.upperLegModel = "frostyHand"
t.lowerLegModel = "frostyHand"
t.toesModel = "frostyPelvis"

t.jumpSounds = ninjaJumps
t.attackSounds = ninjaAttacks
t.impactSounds = ninjaHits
t.deathSounds = ["ninjaDeath1"]
t.pickupSounds = ninjaAttacks
t.fallSounds = ["ninjaFall1"]
t.style = 'bones'