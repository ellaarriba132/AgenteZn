# coding=utf-8
from bsSpaz import Appearance

# SANESSSS!!!
t = Appearance("SANESSSS")
t.colorTexture = "ninjaColor"
t.colorMaskTexture = "ninjaColorMask"
t.iconTexture = "egg2"
t.iconMaskTexture = "achievementTNT"

t.headModel = "ninjaHead"
t.torsoModel = "ninjaTorso"
t.pelvisModel = "ninjaPelvis"
t.upperArmModel = "pixiePelvis"
t.foreArmModel = "pixiePelvis"
t.handModel = "ninjaHand"
t.upperLegModel = "ninjaUpperLeg"
t.lowerLegModel = "ninjaLowerLeg"
t.toesModel = "pixiePelvis"


ninjaAttacks = ['ninjaAttack'+str(i+1)+'' for i in range(7)]
ninjaHits = ['ninjaHit'+str(i+1)+'' for i in range(8)]
ninjaJumps = ['ninjaAttack'+str(i+1)+'' for i in range(7)]

t.jumpSounds = ninjaJumps
t.attackSounds = ninjaAttacks
t.impactSounds = ninjaHits
t.deathSounds = ["ninjaDeath1"]
t.pickupSounds = ninjaAttacks
t.fallSounds = ["ninjaFall1"]
t.style = 'female'