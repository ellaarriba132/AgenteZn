# coding=utf-8
from bsSpaz import *

# SANESSSS!!!
t = Appearance("Bons")

t.colorTexture = "shield"
t.colorMaskTexture = "shield"

t.defaultColor = (1, 1, 1)
t.defaultHighlight = (0.55, 0.8, 0.55)

t.iconTexture = "shield"
t.iconMaskTexture = "bonesIconMask"

t.headModel = "bonesHead"
t.torsoModel = "cyborgTorso"
t.pelvisModel = "ninjaPelvis"
t.upperArmModel = "ninjaUpperArm"
t.foreArmModel = "ninjaForeArm"
t.handModel = "ninjaHand"
t.upperLegModel = "ninjaUpperLeg"
t.lowerLegModel = "ninjaLowerLeg"
t.toesModel = "ninjaToes"

bonesSounds =    ['bones1','bones2','bones3']
bonesHitSounds = ['bones1','bones2','bones3']

t.attackSounds = bonesSounds
t.jumpSounds = bonesSounds
t.impactSounds = bonesHitSounds
t.deathSounds=["bonesDeath"]
t.pickupSounds = bonesSounds
t.fallSounds=["bonesFall"]

t.style = 'bones'