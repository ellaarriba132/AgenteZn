##creado por Lucia

from bsSpaz import *

t = Appearance("PixieProLuci")

t.colorTexture = "pixieColor"
t.colorMaskTexture = "pixieColorMask"

t.iconTexture = "pixieIcon"
t.iconMaskTexture = "pixieIconColorMask"

t.headModel = "pixieHead"
t.torsoModel = "pixieTorso"
t.pelvisModel = "pixiePelvis"
t.upperArmModel = "aliUpperArm"
t.foreArmModel = "aliForeArm"
t.handModel = "agentHand"
t.upperLegModel = "pixieUpperLeg"
t.lowerLegModel = "pixieLowerLeg"
t.toesModel = "pixieToes"

pixieSounds = ['pixie1', 'pixie2', 'pixie3', 'pixie4']
pixieHitSounds = ['pixieHit1', 'pixieHit2']
t.attackSounds = pixieSounds
t.jumpSounds = pixieSounds
t.impactSounds = pixieHitSounds
t.deathSounds = ["pixieDeath"]
t.pickupSounds = pixieSounds
t.fallSounds = ["pixieFall"]

t.style = 'pixie'
