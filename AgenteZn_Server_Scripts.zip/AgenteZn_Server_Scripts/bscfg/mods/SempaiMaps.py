# Si Estas Leyendo Esto... Gracias Por Descargar Mi Mod :3
from bsMap import *
import bsPowerup
import bsUtils
import bs
import portalObjects as obj

class Paradisee():
	# This file generated from 'basketballStadium.blend'
	points = {}
	boxes = {}
	boxes['areaOfInterestBounds'] = (0.4011866709, 2.331310176,-0.5426286416) + (0.0, 0.0, 0.0) + (19.11746262, 10.19675564, 23.50119277)
	boxes['edgeBox'] = (-0.103873591, 0.4133341891, 0.4294651013) + (0.0, 0.0, 0.0) + (22.48295719, 1.290242794, 8.990252454)
	points['ffaSpawn1'] = (-0.08015551329, 0.02275111462, -4.373674593) + (8.895057015, 1.0, 0.444350722)
	points['ffaSpawn2'] = (-0.08015551329, 0.02275111462, 4.076288941) + (8.895057015, 1.0, 0.444350722)
	points['flag1'] = (-10.99027878, 0.05744967453, 0.1095578275)
	points['flag2'] = (11.01486398, 0.03986567039, 0.1095578275)
	points['flagDefault'] = (-0.1001374046, 0.04180340146, 0.1095578275)
	boxes['goal1'] = (12.22454533, 1.0, 0.1087926362) + (0.0, 0.0, 0.0) + (2.0, 2.0, 12.97466313)
	boxes['goal2'] = (-12.15961605, 1.0, 0.1097860203) + (0.0, 0.0, 0.0) + (2.0, 2.0, 13.11856424)
	boxes['levelBounds'] = (0.0, 1.185751251, 0.4326226188) + (0.0, 0.0, 0.0) + (42.09506485, 22.81173179, 29.76723155)
	points['powerupSpawn1'] = (5.414681236, 0.9515026107, -5.037912441)
	points['powerupSpawn2'] = (-5.555402285, 0.9515026107, -5.037912441)
	points['powerupSpawn3'] = (5.414681236, 0.9515026107, 5.148223181)
	points['powerupSpawn4'] = (-5.737266365, 0.9515026107, 5.148223181)
	points['spawn1'] = (-10.03866341, 0.02275111462, 0.0) + (0.5, 1.0, 4.0)
	points['spawn2'] = (9.823107149, 0.01092306765, 0.0) + (0.5, 1.0, 4.0)
	points['tnt1'] = (-0.08421587483, 0.9515026107, -0.7762602271)


class ImpactMap(Map):
	defs = Paradisee()
	name = "ImpactMap"
	playTypes = ['melee','teamFlag','keepAway','conquest','kingOfTheHill','hockey','football','race']
	@classmethod
	def getPreviewTextureName(cls):
		return 'h'
	@classmethod
	def onPreload(cls):
		data = {}
		data['model'] = bs.getModel("hockeyStadiumInner")
		data['vrFillModel'] = bs.getModel('footballStadiumVRFill')
		data['collideModel'] = bs.getCollideModel("footballStadiumCollide")
		data['tex'] = bs.getTexture("eggTex1")
		return data
	def __init__(self):
		Map.__init__(self)
  

		#Circulos del Mapa
		#Configuracion
		color = (0,0,0) # (0,0,0) Recomendado 
		opacidad = 0.6  # 0.5 Recomendado 
		#Centro
		self.zone = bs.newNode('locator',attrs={'shape':'circleOutline','position':(0,0.02,0),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[2.8]})       
	   
		#Izquierda circulo 1
		self.zone = bs.newNode('locator',attrs={'shape':'circleOutline','position':(-6.0,0.02,3.32),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[2.8]})

		#Izquierda circulo 2
		self.zone = bs.newNode('locator',attrs={'shape':'circleOutline','position':(-6.0,0.02,-3.15),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[2.8]})

		#Derecha circulo 1
		self.zone = bs.newNode('locator',attrs={'shape':'circleOutline','position':(5.80,0.02,3.32),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[2.8]})

		#Derecha circulo 2
		self.zone = bs.newNode('locator',attrs={'shape':'circleOutline','position':(5.80,0.02,-3.15),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[2.8]})

		#Centro2
		self.zone = bs.newNode('locator',attrs={'shape':'circle','position':(0,0.02,0),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[0.4]})

		#Izquierda circulo 1.2
		self.zone = bs.newNode('locator',attrs={'shape':'circle','position':(-6.0,0.02,3.32),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[0.4]})       
		
		#Izquierda circulo 2.2
		self.zone = bs.newNode('locator',attrs={'shape':'circle','position':(-6.0,0.02,-3.15),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[0.4]})   
		
		#Derecha circulo 1.2
		self.zone = bs.newNode('locator',attrs={'shape':'circle','position':(5.80,0.02,3.32),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[0.4]})
	   
		#Derecha circulo 2.2
		self.zone = bs.newNode('locator',attrs={'shape':'circle','position':(5.80,0.02,-3.15),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[0.4]})

		self.node = bs.newNode('terrain', delegate=self, attrs={
			'model':self.preloadData['model'],        
			'collideModel':self.preloadData['collideModel'],
			'colorTexture':self.preloadData['tex'],
			'materials':[bs.getSharedObject('footingMaterial')]})

		bs.newNode('terrain',
				   attrs={'model':self.preloadData['vrFillModel'],
						  'lighting':False,
						  'vrOnly':True,
						  'background':True,
						  'colorTexture':None})

		self.background = bs.newNode(
			'terrain',
			attrs={
				'model': bs.getModel('natureBackground'),
				'lighting': False,
				'background': True,
				'color': (0.10,0.30,0.50)
			})
		g = bs.getSharedObject('globals')
		g.tint = (1.3, 1.2, 1.0)
		g.ambientColor = (1.3, 1.2, 1.0)
		g.vignetteOuter = (0.57, 0.57, 0.57)
		g.vignetteInner = (0.9, 0.9, 0.9)
		g.vrCameraOffset = (0, -0.8, -1.1)
		g.vrNearClip = 0.5

		
	def _isPointNearEdge(self,p,running=False):
		boxPosition = self.defs.boxes['edgeBox'][0:3]
		boxScale = self.defs.boxes['edgeBox'][6:9]
		x = (p.x() - boxPosition[0])/boxScale[0]
		z = (p.z() - boxPosition[2])/boxScale[2]
		return (x < -0.5 or x > 0.5 or z < -0.5 or z > 0.5)
registerMap(ImpactMap)

class DarkSquareMap(Map):
	defs = Paradisee()
	name = "DarkSquareMap"
	playTypes = ['melee','teamFlag','keepAway','conquest','kingOfTheHill','hockey','football','race','billiard']
	@classmethod
	def getPreviewTextureName(cls):
		return 'powerupShield'
	@classmethod
	def onPreload(cls):
		data = {}
		data['model'] = bs.getModel("hockeyStadiumInner")
		data['vrFillModel'] = bs.getModel('footballStadiumVRFill')
		data['collideModel'] = bs.getCollideModel("footballStadiumCollide")
		data['tex'] = bs.getTexture("powerupStickyBombs")
		return data
	def __init__(self):
		Map.__init__(self)
	
			
		#Circulos del Mapa
		#Configuracion
		color = (0,0,0) # (0,0,0) Recomendado 
		opacidad = 0.6  # 0.5 Recomendado 
		#Centro
		self.zone = bs.newNode('locator',attrs={'shape':'circleOutline','position':(0,0.02,0),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[2.8]})       
	   
		#Izquierda circulo 1
		self.zone = bs.newNode('locator',attrs={'shape':'circleOutline','position':(-6.0,0.02,3.32),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[2.8]})

		#Izquierda circulo 2
		self.zone = bs.newNode('locator',attrs={'shape':'circleOutline','position':(-6.0,0.02,-3.15),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[2.8]})

		#Derecha circulo 1
		self.zone = bs.newNode('locator',attrs={'shape':'circleOutline','position':(5.80,0.02,3.32),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[2.8]})

		#Derecha circulo 2
		self.zone = bs.newNode('locator',attrs={'shape':'circleOutline','position':(5.80,0.02,-3.15),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[2.8]})

		#Centro2
		self.zone = bs.newNode('locator',attrs={'shape':'circle','position':(0,0.02,0),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[0.4]})

		#Izquierda circulo 1.2
		self.zone = bs.newNode('locator',attrs={'shape':'circle','position':(-6.0,0.02,3.32),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[0.4]})       
		
		#Izquierda circulo 2.2
		self.zone = bs.newNode('locator',attrs={'shape':'circle','position':(-6.0,0.02,-3.15),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[0.4]})   
		
		#Derecha circulo 1.2
		self.zone = bs.newNode('locator',attrs={'shape':'circle','position':(5.80,0.02,3.32),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[0.4]})
	   
		#Derecha circulo 2.2
		self.zone = bs.newNode('locator',attrs={'shape':'circle','position':(5.80,0.02,-3.15),
		'color':color, 'opacity':opacidad, 'drawShadow': False,  'drawBeauty':True, 'additive':False, 'size':[0.4]})
		

  
		self.node = bs.newNode('terrain', delegate=self, attrs={
			'model':self.preloadData['model'],        
			'collideModel':self.preloadData['collideModel'],
			'colorTexture':self.preloadData['tex'],
			'materials':[bs.getSharedObject('footingMaterial')]})

		self.background = bs.newNode(
			'terrain',
			attrs={
				'model': bs.getModel('natureBackground'),
				'lighting': False,
				'background': True,
				'color': (0.10,0.30,0.50)
			})

		bs.newNode('terrain',
				   attrs={'model':self.preloadData['vrFillModel'],
						  'lighting':False,
						  'vrOnly':True,
						  'background':True})
		g = bs.getSharedObject('globals')
		g.tint = (1.3, 1.2, 1.0)
		g.ambientColor = (1.3, 1.2, 1.0)
		g.vignetteOuter = (0.57, 0.57, 0.57)
		g.vignetteInner = (0.9, 0.9, 0.9)
		g.vrCameraOffset = (0, -0.8, -1.1)
		g.vrNearClip = 0.5
		
	def _isPointNearEdge(self,p,running=False):
		boxPosition = self.defs.boxes['edgeBox'][0:3]
		boxScale = self.defs.boxes['edgeBox'][6:9]
		x = (p.x() - boxPosition[0])/boxScale[0]
		z = (p.z() - boxPosition[2])/boxScale[2]
		return (x < -0.5 or x > 0.5 or z < -0.5 or z > 0.5)
registerMap(DarkSquareMap)

class TowerDMap2(Map):
	import towerDLevelDefs as defs
	name = 'Torre D!!'
	playTypes = ['melee', 'keepAway', 'teamFlag', 'conquest', 'kingOfTheHill']

	@classmethod
	def getPreviewTextureName(cls):
		return 'towerDPreview'

	@classmethod
	def onPreload(cls):
		data = {}
		data['model'] = bs.getModel('towerDLevel')
		data['modelBottom'] = bs.getModel('towerDLevelBottom')
		data['collideModel'] = bs.getCollideModel('towerDLevelCollide')
		data['tex'] = bs.getTexture('towerDLevelColor')
		data['bgTex'] = bs.getTexture('black')
		# fixme should chop this into vr/non-vr sections
		data['bgModel'] = bs.getModel('tipTopBG')
		data['playerWallCollideModel'] = bs.getCollideModel('towerDPlayerWall')
		data['playerWallMaterial'] = bs.Material()
		data['playerWallMaterial'].addActions(actions=(('modifyPartCollision',
														'friction', 10.0)))
		# anything that needs to hit the wall can apply this material
		data['collideWithWallMaterial'] = bs.Material()
		data['playerWallMaterial'].addActions(
			conditions=('theyDontHaveMaterial',data['collideWithWallMaterial']),
			actions=(('modifyPartCollision','collide',False)))
		data['vrFillMoundModel'] = bs.getModel('stepRightUpVRFillMound')
		data['vrFillMoundTex'] = bs.getTexture('vrFillMound')
		return data

	def __init__(self):
		Map.__init__(self,vrOverlayCenterOffset=(0,1,1))
		self.node = bs.newNode('terrain', delegate=self, attrs={
			'collideModel':self.preloadData['collideModel'],
			'model':self.preloadData['model'],
			'colorTexture':self.preloadData['tex'],
			'materials':[bs.getSharedObject('footingMaterial')]})
		self.nodeBottom = bs.newNode('terrain', delegate=self, attrs={
			'model':self.preloadData['modelBottom'],
			'lighting':False,
			'colorTexture':self.preloadData['tex']})
		bs.newNode('terrain', attrs={
			'model':self.preloadData['vrFillMoundModel'],
			'lighting':False,
			'vrOnly':True,
			'color':(0.53,0.57,0.5),
			'background':True,
			'colorTexture':self.preloadData['vrFillMoundTex']})
		self.bg = bs.newNode('terrain', attrs={
			'model':self.preloadData['bgModel'],
			'lighting':False,
			'background':True,
			'colorTexture':self.preloadData['bgTex']})
		self.playerWall = bs.newNode('terrain', attrs={
			'collideModel':self.preloadData['playerWallCollideModel'],
			'affectBGDynamics':False,
			'materials':[self.preloadData['playerWallMaterial']]})
		bsGlobals = bs.getSharedObject('globals')
		bsGlobals.tint = (1.15, 1.11, 1.03)
		bsGlobals.vignetteOuter = (0.86, 0.86, 0.86)
		bsGlobals.vignetteInner = (0.95, 0.95, 0.99)

		#Portals
		obj.Portal(position1=(-8.7, 4.2, 0),
				   position2=(8.1, 3.2, 0),
				   color=(9/2, 8/2, 0))


	def _isPointNearEdge(self,p,running=False):
		# see if we're within edgeBox
		boxes = self.defs.boxes
		boxPosition = boxes['edgeBox'][0:3]
		boxScale = boxes['edgeBox'][6:9]
		boxPosition2 = boxes['edgeBox2'][0:3]
		boxScale2 = boxes['edgeBox2'][6:9]
		x = (p.x() - boxPosition[0])/boxScale[0]
		z = (p.z() - boxPosition[2])/boxScale[2]
		x2 = (p.x() - boxPosition2[0])/boxScale2[0]
		z2 = (p.z() - boxPosition2[2])/boxScale2[2]
		# if we're outside of *both* boxes we're near the edge
		return ((x < -0.5 or x > 0.5 or z < -0.5 or z > 0.5)
				and (x2 < -0.5 or x2 > 0.5 or z2 < -0.5 or z2 > 0.5))

registerMap(TowerDMap2)

class LakeFrigidMap2(Map):
	import lakeFrigidDefs as defs
	name = 'Lago Frigido!!'
	playTypes = ['melee', 'keepAway', 'teamFlag', 'race']

	@classmethod
	def getPreviewTextureName(cls):
		return 'lakeFrigidPreview'

	@classmethod
	def onPreload(cls):
		data = {}
		data['model'] = bs.getModel('lakeFrigid')
		data['modelTop'] = bs.getModel('lakeFrigidTop')
		data['modelReflections'] = bs.getModel('lakeFrigidReflections')
		data['collideModel'] = bs.getCollideModel('lakeFrigidCollide')
		data['tex'] = bs.getTexture('lakeFrigid')
		data['texReflections'] = bs.getTexture('lakeFrigidReflections')
		data['vrFillModel'] = bs.getModel('lakeFrigidVRFill')
		m = bs.Material()
		m.addActions(actions=('modifyPartCollision','friction',0.01))
		data['iceMaterial'] = m
		return data

	def __init__(self):
		Map.__init__(self)
		self.node = bs.newNode('terrain', delegate=self, attrs={
			'collideModel':self.preloadData['collideModel'],
			'model':self.preloadData['model'],
			'colorTexture':self.preloadData['tex'],
			'materials':[bs.getSharedObject('footingMaterial'),
						 self.preloadData['iceMaterial']]})
		bs.newNode('terrain', attrs={
			'model':self.preloadData['modelTop'],
			'lighting':False,
			'colorTexture':self.preloadData['tex']})
		bs.newNode('terrain', attrs={
			'model':self.preloadData['modelReflections'],
			'lighting':False,
			'overlay':True,
			'opacity':0.15,
			'colorTexture':self.preloadData['texReflections']})
		bs.newNode('terrain', attrs={
			'model':self.preloadData['vrFillModel'],
			'lighting':False,
			'vrOnly':True,
			'background':True,
			'colorTexture':self.preloadData['tex']})
		g = bs.getSharedObject('globals')
		g.tint = (1, 1, 1)
		g.ambientColor = (1, 1, 1)
		g.shadowOrtho = True
		g.vignetteOuter = (0.86, 0.86, 0.86)
		g.vignetteInner = (0.95, 0.95, 0.99)
		g.vrNearClip = 0.5
		self.isHockey = False

registerMap(LakeFrigidMap2)


class MapaInvisible(Map):
	import footballStadiumDefs as defs
	name = 'Negro Y Blanco'
	playTypes = ['melee', 'keepAway', 'teamFlag']

	@classmethod
	def getPreviewTextureName(cls):
		return 'achievementOutLine'

	@classmethod
	def onPreload(cls):
		data = {}
		data['collideModel'] = bs.getCollideModel('footballStadiumCollide')
		data['bgTex'] = bs.getTexture('menuBG')
		data['bgModel'] = bs.getModel('thePadBG')
		return data

	def __init__(self):
		Map.__init__(self)
		self.node = bs.newNode('terrain', delegate=self, attrs={
			'collideModel':self.preloadData['collideModel'],
			'materials':[bs.getSharedObject('footingMaterial')]})
		self.foo = bs.newNode('terrain', attrs={
			'model':self.preloadData['bgModel'],
			'lighting':False,
			'background':True,
			'colorTexture':self.preloadData['bgTex']})
		bsGlobals = bs.getSharedObject('globals')
		bsGlobals.tint = (0.82, 1.10, 1.15)
		bsGlobals.ambientColor = (0.9, 1.3, 1.1)
		bsGlobals.vignetteOuter = (0.76, 0.76, 0.76)
		bsGlobals.vignetteInner = (0.95, 0.95, 0.99)
	def _isPointNearEdge(self,p,running=False):
		x = p.x()
		z = p.z()
		xAdj = x*0.125
		zAdj = (z+3.7)*0.2
		if running:
			xAdj *= 1.4
			zAdj *= 1.4
		return (xAdj*xAdj+zAdj*zAdj > 1.0)

registerMap(MapaInvisible)

