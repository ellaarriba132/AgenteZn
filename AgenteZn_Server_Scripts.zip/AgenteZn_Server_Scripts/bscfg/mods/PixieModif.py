# coding=utf-8
from bsSpaz import *

##Created by ##################

t = Appearance("PixieMD")
t.colorTexture = "pixieColor"
t.colorMaskTexture = "pixieColorMask"
t.defaultColor = (0.5,0.5,0.5)
t.defaultHighlight = (1,0,0)
t.iconTexture = "zoeIcon"
t.iconMaskTexture = "pixieIconColorMask"
t.headModel =     "pixieHead"
t.torsoModel =    "pixieTorso"
t.pelvisModel =   "pixiePelvis"
t.upperArmModel = "aliUpperArm"
t.foreArmModel =  "aliForeArm"
t.handModel =     "cyborgHand"
t.upperLegModel = "pixieUpperLeg"
t.lowerLegModel = "pixieLowerLeg"
t.toesModel =     "cyborgToes"
pixieSounds =    ['pixie1','pixie2','pixie3','pixie4']
pixieHitSounds = ['pixieHit1','pixieHit2']
t.attackSounds = pixieSounds
t.jumpSounds = frostySounds
t.impactSounds = penguinHitSounds
t.deathSounds=["pixieDeath"]
t.pickupSounds = pixieSounds
t.fallSounds=["penguinFall"]
t.style = 'pixie'