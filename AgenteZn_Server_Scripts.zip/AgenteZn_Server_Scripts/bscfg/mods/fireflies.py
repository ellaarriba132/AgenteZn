import bs, bsInternal, bsMap, bsGame
import random
from bsGame import GameActivity, Activity, OutOfBoundsMessage
import random

#lo saque de los scripts de smooth no me pertenece solo lo portee a la version antigua que es 1.4

onBegin_original = bsGame.Activity.onBegin

def fireflies_generator(activity, count, random_color=False):
	if random_color:
		color=(random.uniform(0,1.2),random.uniform(0,1.2),random.uniform(0,1.2))
	else:
		color=(0.9,0.7,0.0)
	increment = count - len(activity.fireflies)

	if increment > 0:
		spawn_areas = _calculate_spawn_areas()
		if not spawn_areas:
			return
		for _ in range(increment):
			with bs.Context(activity):
				firefly = flies(random.choice(spawn_areas), color)
			activity.fireflies.append(firefly)
	else:
		for _ in range(abs(increment)):
			firefly = activity.fireflies.pop()
			try:
				firefly.handleMessage(bs.DieMessage())
			except AttributeError:
				pass
			firefly.timer = None

def _calculate_spawn_areas():
	activity=bsInternal._getForegroundHostActivity()
	if not isinstance(activity, bs.GameActivity):
		return
	m=activity.getMap().getDefBoundBox('areaOfInterestBounds')
	first_half = list(m)
	second_half = list(m)
	midpoint_x = (m[0] + m[3]) / 2
	first_half[3] = midpoint_x
	second_half[0] = midpoint_x
	spawn_areas = (first_half, second_half)
	return spawn_areas
	# bs.gameTimer(3,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(1,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(12,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(88,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(8,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(3,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(78,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(2,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(6,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(33,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(8,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(2,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(83,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(5,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(28,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(22,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(61,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(22,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(31,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(22,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(61,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(21,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(42,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(22,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(16,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(27,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(11,bs.Call(create_fly,part1,random_col))
	# bs.gameTimer(12,bs.Call(create_fly,part2,random_col))
	# bs.gameTimer(20,bs.Call(create_fly,part1,random_col))


# def create_fly(points,random_col):
# 	flies(points,random_col).autoRetain()

# class fliesFactory(object):
# 	def __init__(self):
# 		self.mat = bs.Material()
# 		self.mat.addActions(
# 					actions=(
# 						('modifyPartCollision', 'collide', False),
# 						('modifyPartCollision','physical',False),
# 				))

class flies(bs.Actor):
	def __init__(self, area, color, *args, **kwargs):
		bs.Actor.__init__(self)
		self.area = area
		self.color = color
		initial_timer = random.uniform(0.5, 6)
		self.timer = bs.Timer(int(initial_timer), self.on)
	def on(self):
		position = (0.0, 5.0, -4.0)
		self.mat = bs.Material()
 		self.mat.addActions(
 					actions=(
 						('modifyPartCollision', 'collide', False),
 						('modifyPartCollision','physical',False),
 					))
		self.node = bs.newNode(
			'prop',
			owner=None,
			attrs={
			'model':bs.getModel('bomb'),
			#'position':position,
			'body':'capsule',
			'shadowSize':0.0,
			'colorTexture':random.choice([bs.getTexture(tex) for tex in ("egg1", "egg2", "egg3")]),
			'reflection':'soft',
			#'isAreaOfInterest':True,
			'reflectionScale':[1.5],
			'materials':[bs.getSharedObject('objectMaterial'),self.mat]
			},delegate=self)

		
		bs.animate(
			self.node,
			'modelScale',
			{0:0, 1000:0.15, 5000:0.10, 10000:0.0},
			loop=True,
		)
		bs.animateArray(
			self.node,
			'position',
			3,
			self.generateKeys(self.area),
			loop=True
		)

		self.light = bs.newNode(
			'light',
			owner=self.node,
			attrs={
				'intensity':0.6,
				'heightAttenuated':True,
				'radius':0.2,
				'color':self.color
			})
		bs.animate(
			self.light,
			'radius',
			{0:0.0, 2000:0.3 ,7000:0.01 ,10000:0.2 ,15000:0},
			loop=True
		)
		self.node.connectAttr('position', self.light, 'position')

	def off(self):
		death_secs = random.uniform(0.5, 3)
		with bs.Context(self._activity()):
			bs.animate(
				self.node,
				'modelScale',
				{0: self.node.modelScale, death_secs: 0}
			)
			bs.animate(
				self.light,
				'radius',
				{0:self.light.radius, death_secs:0}
			)
			self.time=bs.Timer(int(death_secs), self.node.delete)

	def handleMessage(self,msg):
		if isinstance(msg,bs.DieMessage):

			self.off()

		elif isinstance(msg,bs.OutOfBoundsMessage):
			self.node.position = (0.0, 5.0, -4.0)
			self.handleMessage(bs.DieMessage(how='OutOfBoundsMessage'))
		else:
			bs.Actor.handleMessage(self,msg)

	def generateKeys(self,m):
		
		keys={}
		t=0
		
		last_x=random.randrange(int(m[0]),int(m[3]))
		last_y=random.randrange(int(m[1]),int(m[4]))
		if int(m[2])==int(m[5]):
			last_z=int(m[2])
		else:
			last_z=random.randrange(int(m[2]),int(m[5]))
		for i in range(0,7):
			x=self.generateRandom(int(m[0]),int(m[3]),last_x)
			last_x=x
			y=self.generateRandom(int(m[1]),int(m[4]),last_y)
			last_y=y
			z=self.generateRandom(int(m[2]),int(m[5]),last_z)
			last_z=z
			keys[t]=(x,abs(y),z)
			t +=10000
		
		return keys
	def generateRandom(self,a,b,z):
		if a==b:
			return a

		while True:
			n= random.randrange(a,b)
			if abs(z-n) < 6:
				return n

def onBegin(self, *args, **kwargs):
	self.fireflies = []
	return onBegin_original(self, *args, **kwargs)

bsGame.Activity.fireflies_generator = fireflies_generator
bsGame.Activity.onBegin = onBegin
