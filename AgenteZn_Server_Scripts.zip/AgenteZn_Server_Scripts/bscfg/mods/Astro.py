# coding=utf-8
from bsSpaz import *

# SANESSSS!!!
t = Appearance("astro")
t.colorTexture = "landMineLit"
t.colorMaskTexture = "landMineLit"
t . defaultColor = (1.0, 0.1, 1.2)

t . defaultHighlight = (0.16, 0.15, 2.4)
t.iconTexture = "landMineLit"
t.iconMaskTexture = "aliIconMask"

t.headModel = "bomb"
t.torsoModel = "cyborgPelvis"
t.pelvisModel = "cyborgPelvis"
t.upperArmModel = "agentUpperArm"
t.foreArmModel = "agentForeArm"
t.handModel = "cyborgHand"
t.upperLegModel = "cyborgUpperLeg"
t.lowerLegModel = "cyborgLowerLeg"
t.toesModel = "cyborgToes"

cyborgSounds =    ['cyborg1','cyborg2','cyborg3','cyborg4']
cyborgHitSounds = ['cyborgHit1','cyborgHit2']
t.attackSounds = cyborgSounds
t.jumpSounds = cyborgSounds
t.impactSounds = cyborgHitSounds
t.deathSounds=["cyborgDeath"]
t.pickupSounds = cyborgSounds
t.fallSounds=["cyborgFall"]
t . style = 'agent'