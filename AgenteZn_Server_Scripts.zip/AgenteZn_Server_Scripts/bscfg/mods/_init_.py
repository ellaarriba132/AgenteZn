import bs
import os
import sys

print 'Github: https://github.com/ellaarriba132/AgenteZn.git\n\nDiscord: https://discord.gg/KAYembFsxK\n\nYour server is opening...'
